/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Minggu5;

/**
 *
 * @author Benny
 */
public class OrderedSearch {
    public double[] arr;
    
    
    public OrderedSearch(double ArrayNilai[]){
        arr = new double[ArrayNilai.length];
        for(int i = 0; i<arr.length; i++){
            arr[i]=ArrayNilai[i];
            
        }
    }
    public int cari (double keyword){
        int index = -1;
        for(int i = 0; i<arr.length; i++){
            if(keyword==arr[i]){
                index=i;
                break;
            } else {
                if (keyword<arr[i]){
                    break;
                    
                }
            }
        }    
        return index;
    }
    
    public void Tampilkan(){
        for(int i=0; i<arr.length;i++){
            System.out.println("");
        }
    }
}     
    
    

