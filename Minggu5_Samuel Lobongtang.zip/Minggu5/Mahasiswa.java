/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Minggu5;

/**
 *
 * @author Benny
 */
public class Mahasiswa {
    public String nim;
    public String namaMahasiswa;
    public double ipk;
    
    public Mahasiswa(String id, String nama, double gpa){
        nim=id;
        namaMahasiswa=nama;
        ipk=gpa;
        
        
        
    }
    
}
