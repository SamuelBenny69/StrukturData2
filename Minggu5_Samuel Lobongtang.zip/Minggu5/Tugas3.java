/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Minggu5;

/**
 *
 * @author Benny
 */
public class Tugas3 {
    public static void main(String[] args) {
        // TODO code application logic here
        int[] arr = {12, 15, 6, 3, 70, 51, 83, 15, 3, 83};

        int max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        System.out.println("Nilai terbesar pada array adalah: " + max);

        System.out.print("Nilai terbesar ditemukan pada posisi: ");
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == max) {
                System.out.print(i + " ");
            }
        }
    }
    
}

        
   
