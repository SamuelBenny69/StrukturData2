/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Minggu5;

/**
 *
 * @author Benny
 */
public class Tuagas1 {
    public static int search(int arr[], int x){
        int n = arr.length;
        for (int i = 0; i < n; i++){
            if (arr[i] == x) {
                return i;
            }
        }
        return -1;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int arr []= {17, 20, 26, 33, 37, 41, 52, 65, 73, 83};
        int x = 41;
        
        int hasil = search(arr,x);
        if (hasil == -1) {
            System.out.println("Elemen yang dicari tidak ada didalam array");
        } else{
            System.out.println("Elemen berada pada index "+ hasil);
        }
    }
    
}

    
    
