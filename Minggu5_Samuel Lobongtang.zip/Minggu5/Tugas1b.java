/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Minggu5;

/**
 *
 * @author Benny
 */
public class Tugas1b {
     public static boolean search(int[] arr, int x ){
        for (int i = 0; i < arr.length; i++){
            if (arr[i] == x){
                return true;
            }
        }
        return false;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[]arr = {17, 20, 26, 33, 37, 41, 53, 65, 73, 83};
        int x = 50;
        
        boolean ditemukan = search (arr,x);
        if (ditemukan){
            System.out.println("Data ditemukan di array");
            
        } else{
            System.out.println("Data tidak ditemukan di array");
        }
    }
    
}

    
    

