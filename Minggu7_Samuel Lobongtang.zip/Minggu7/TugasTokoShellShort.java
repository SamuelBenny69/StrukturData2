/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Minggu7;

/**
 *
 * @author Benny
 */
public class TugasTokoShellShort {
    public static void main(String[] args) {
        
        // data barang
        String[] namaBarang = {"Pensil", "Buku", "Penggaris", "Bulpen"};
        int[] stokBarang = {35, 20, 50, 25};
        int[] hargaBarang = {1000, 5000, 1500, 2000};
        
        // melakukan pengurutan dengan shell sort berdasarkan stok
        int jarak = stokBarang.length / 2;
        while (jarak > 0) {
            for (int i = jarak; i < stokBarang.length; i++) {
                int key = stokBarang[i];
                String namaKey = namaBarang[i];
                int hargaKey = hargaBarang[i];
                int j = i;
                while (j >= jarak && stokBarang[j - jarak] < key) {
                    stokBarang[j] = stokBarang[j - jarak];
                    namaBarang[j] = namaBarang[j - jarak];
                    hargaBarang[j] = hargaBarang[j - jarak];
                    j -= jarak;
                }
                stokBarang[j] = key;
                namaBarang[j] = namaKey;
                hargaBarang[j] = hargaKey;
            }
            jarak /= 2;
        }
        
        // menampilkan hasil pengurutan
        System.out.println("Hasil pengurutan berdasarkan stok:");
        System.out.println("Nama Barang\tStok\tHarga");
        for (int i = 0; i < stokBarang.length; i++) {
            System.out.println(namaBarang[i] + "\t\t" + stokBarang[i] + "\t" + hargaBarang[i]);
        }
    }


    
}


 
