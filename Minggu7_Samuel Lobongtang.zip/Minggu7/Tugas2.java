/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Minggu7;

/**
 *
 * @author Benny
 */
public class Tugas2 {
    String nama;
    int nilaiA, nilaiB, nilaiC, total;

    public Tugas2(String nama, int nilaiA, int nilaiB, int nilaiC) {
        this.nama = nama;
        this.nilaiA = nilaiA;
        this.nilaiB = nilaiB;
        this.nilaiC = nilaiC;
        this.total = nilaiA + nilaiB + nilaiC;
    }
    
}


